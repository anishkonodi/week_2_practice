class example2 {
  public static void main(String args[]) {
    byte a = 1;
    int b = 2;
    short c = 3;
    long d = 4;
    float e = 5;
    double f = 6.0;
    char g = 'c';
    boolean i = true;
    String h = "welcome";
    System.out.println("byte value is " + a);
    System.out.println("int value is  " + b);
    System.out.println("short value is " + c);
    System.out.println("long value is " + d);
    System.out.println("float value is " + e);
    System.out.println("double value is " + f);
    System.out.println("character is " + g);
    System.out.println("boolean value is  " + i);
    System.out.println("string is " + h);
  }
}