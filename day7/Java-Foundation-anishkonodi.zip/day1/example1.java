class example1{
  
  public static void main(String args[]){
    System.out.println("welcome to java");
    int x=5, y=5,z=0;
    z=x+y;
      System.out.println("sum is "+z);
  }
}